### LUA EXEC BYPASS
![Java](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Windows](https://img.shields.io/badge/-Winodows-28C2FF?style=for-the-badge&logo=windows&logoColor=blue)
![VS](https://img.shields.io/badge/Visual_Studio_Code-0078D4?style=for-the-badge&logo=visual%20studio%20code&logoColor=white)
 
### ❌〢 HEY ! (Scroll down the text to read more)

- **06/10/2022** You must use it at your own risk.
- You can study the source more about it. For more questions Join  [Discord Server](https://discord.gg/MBTkVcJefp)


  
#### 1. Create Folder in C:\Test
> put ur lua file there rename it to "Test.lua" 


#### 2. Download File Exec Bypass + Modmap [Download](https://github.com/SarnaxLii/Exec-cmd/releases/tag/Fivem)

#### 3. Drag Driver.sys to kdmapper.exe
![image](https://user-images.githubusercontent.com/94861415/152669396-1e15edf2-48bf-453a-970d-d726ad4c15f6.png)

#### 4. Open FiveM 

#### 5. Open Task Manager > Details > FiveM_b2372_GTAProcess.exe (The numbers in front of the letter B may not be the same)
![image](https://user-images.githubusercontent.com/94861415/152669415-d7ec29c9-a5e3-4f15-88f4-dc2b5eb8f2c1.png)

#### 6. Open CMD ( Run as Admin )

```
cd C:\Users\Sarnax\Desktop\modmap\modmap
```


```
modmap.exe FiveM_b2372_GTAProcess.exe d3d11.dll bypass.dll
```

![image](https://user-images.githubusercontent.com/94861415/152669463-dccc0237-0dad-4d01-9d1d-432c0c0f98b0.png)

![image](https://user-images.githubusercontent.com/94861415/152669486-def2e29b-5982-44b3-99ad-680a1d151650.png)


---

  <p align="center">
    <a href="https://discord.com/users/943374631644045363">
        <img title="Fnoberz server discord" alt="Fnoberz's discord" src="https://discord.c99.nl/widget/theme-4/943374631644045363.png"/>
    </a>
</p> 
 
### 💬 Discord ・[CLOUD OFFICIAL](https://discord.gg/MBTkVcJefp) 

### 🛒〢 Private Cheat.
`PRIVATE CHEATING | SPOOFER | SOURCE CODE | DRIVER | ETC`
#### Read more details here. [Information](https://github.com/Cloud-Official/Product) 

### 🟢〢 Advantage

- Driver Bypass
- Lifetime + Update Free
- Custom Feature if you want (**For example AIMBOT + ESP** || We'll warn you if a feature isn't secure.)
- Safe and Legit


### 🔱〢 Warranty Product.

- Support 24 Hr
- Update Free
- IF Banned = REFUND

---

A website that I created to introduce myself from start to finish. hope you like it [Fnoberz.com](https://fnoberz.com/)

#### If you don't understand, contact Discord to ask.

![unknown](https://user-images.githubusercontent.com/94861415/152669512-640736bc-7139-4097-9f5c-d51545ea64ee.png)



<h2 align="center"> Copyright © 2021 - 2022

##### <p align="center">  FNOBERZ OFFICIAL / JOIN DISCORD [CLOUD PROJECT](https://discord.gg/JUwFCGHbV4)
